package com.example.login;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    @FXML
    private Button exit;

    @FXML
    private AnchorPane bg;

    @FXML
    private Button logIn;

    @FXML
    private Text signUp;

    @FXML
    private TextField passWd;


    @FXML
    private TextField usrNm;

    @FXML
    private Text fgtPwd;

    @FXML
    // close event
    void exit(MouseEvent event) {
        Stage stage = (Stage) exit.getScene().getWindow();
        stage.close();
    }

    @FXML
    //login event
    void logIn(MouseEvent event) throws IOException {
        //credential check
        String usr = usrNm.getText(), pwd = passWd.getText();
        if((usr == null) || (usr =="")){
            usrNm.setStyle("-fx-prompt-text-fill:red;");
            System.out.println("usr empty");
            if((pwd == null) || (pwd =="")){
                System.out.println("pwd empty");
                passWd.setStyle("-fx-prompt-text-fill:red;");
            }
        }else if((usr != null) || (usr !="")){
            System.out.println("usr not empty");
            if((pwd == null) || (pwd =="")){
                System.out.println("pwd empty");
                passWd.setStyle("-fx-prompt-text-fill:red;");
            }else if((pwd != null) || (pwd !="")){

                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("loginapi.fxml"));
                Scene logapiscene = new Scene(fxmlLoader.load(), 600, 400);
                Stage logapi = (Stage) passWd.getScene().getWindow();
                logapi.setScene(logapiscene);

                System.out.println("pwd not empty");
            }
        }



    }


}