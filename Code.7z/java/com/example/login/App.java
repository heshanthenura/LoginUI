package com.example.login;

public class App {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
